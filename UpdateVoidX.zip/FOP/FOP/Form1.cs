﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Media; // Add this for SoundPlayer
using System.Net; // Add this for WebClient
using System.Windows.Forms;

namespace FOP
{
    public partial class Form1 : Form
    {
        Timer time = new Timer();        // Timer for checking Roblox status
        Timer fadeOutTimer = new Timer();  // Timer for fade-out animation
        Timer fadeInTimer = new Timer();   // Timer for fade-in animation
        public Point mouseLocation;
        private bool soundIsPlaying = false; // Flag to check if sound is playing

        private const string updateUrl = "https://example.com/path/to/your/latest_version.exe"; // URL for the latest version
        private const string currentVersion = "1.0.6"; // Current version of your application
        private const string versionFileUrl = "https://github.com/1378544/Yes/blob/main/version.txt"; // URL for the version file

        public Form1()
        {
            InitializeComponent();

            // Check for updates
            CheckForUpdates();

            // Set the initial opacity to 0 for fade-in effect
            this.Opacity = 0;

            // Set up the regular timer
            time.Tick += timertick;
            time.Start();

            // Set up the fade-out timer
            fadeOutTimer.Interval = 10;  // Interval in milliseconds for smooth fade
            fadeOutTimer.Tick += fadeOutTimer_Tick;  // Link fade timer to event handler

            // Set up the fade-in timer
            fadeInTimer.Interval = 10; // Interval for fade-in
            fadeInTimer.Tick += fadeInTimer_Tick; // Link fade-in timer to event handler

            // Link PictureBox click event
            this.pictureBox1.Click += new EventHandler(this.pictureBox1_Click);

            // Start the fade-in effect
            fadeInTimer.Start();
        }

        // Method to check for updates
        private void CheckForUpdates()
        {
            using (WebClient webClient = new WebClient())
            {
                try
                {
                    string latestVersion = webClient.DownloadString(versionFileUrl).Trim();
                    if (latestVersion != currentVersion)
                    {
                        DialogResult result = MessageBox.Show("A new version is available. Would you like to update?", "Update Available", MessageBoxButtons.YesNo);
                        if (result == DialogResult.Yes)
                        {
                            UpdateApplication();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error checking for updates: " + ex.Message);
                }
            }
        }

        // Method to update the application
        private void UpdateApplication()
        {
            using (WebClient webClient = new WebClient())
            {
                try
                {
                    string tempFilePath = Path.Combine(Path.GetTempPath(), "updated_version.exe");
                    webClient.DownloadFile(updateUrl, tempFilePath);

                    // Start the update process
                    System.Diagnostics.Process.Start(tempFilePath);
                    Application.Exit(); // Exit current application
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating application: " + ex.Message);
                }
            }
        }

        // Timer tick method to check Roblox status and update UI
        private void timertick(object sender, EventArgs e)
        {
            // Check if Roblox is open
            if (ForlornApi.Api.IsRobloxOpen())
            {
                robloxopen.Text = " "; // Clear text when Roblox is open
                robloxopen.ForeColor = Color.LightGreen;

                // Check the injection status
                if (ForlornApi.Api.IsInjected())
                {
                    status.Text = "Injected!"; // Update status to "Injected!"
                    status.ForeColor = Color.LightGreen;

                    // Check if sound is already playing to avoid overlapping sounds
                    if (!soundIsPlaying)
                    {
                        PlayInjectionSound(); // Play sound when injected
                        soundIsPlaying = true; // Set flag to indicate sound is playing
                    }
                }
                else
                {
                    status.Text = "Not Injected!"; // Update status to "Not Injected!"
                    status.ForeColor = Color.Red; // Change text color to red
                    soundIsPlaying = false; // Reset sound playing flag
                }
            }
            else
            {
                robloxopen.ForeColor = Color.Red; // Change Roblox status text color to red
                status.Text = " "; // Clear status text when Roblox is not open

                // Show waiting message when Roblox is not open
                robloxopen.Text = "Waiting for Roblox"; // Show waiting message
            }
        }

        // Method to play the injection sound
        private void PlayInjectionSound()
        {
            // Path to the sound file in the Resources folder
            string soundFilePath = Path.Combine(Application.StartupPath, "Resources", "inject_sound.wav");

            // Play the sound effect
            using (SoundPlayer player = new SoundPlayer(soundFilePath))
            {
                player.Play(); // Play the sound
            }
        }

        // Fade-out logic to reduce opacity step-by-step
        private void fadeOutTimer_Tick(object sender, EventArgs e)
        {
            if (this.Opacity > 0)  // Reduce opacity gradually
            {
                this.Opacity -= 0.05;  // Decrease opacity by 5% at each tick
            }
            else
            {
                fadeOutTimer.Stop();  // Stop the timer when opacity reaches 0
                this.Close();  // Close the form after fade-out
            }
        }

        // Fade-in logic to increase opacity step-by-step
        private void fadeInTimer_Tick(object sender, EventArgs e)
        {
            if (this.Opacity < 1) // Increase opacity gradually
            {
                this.Opacity += 0.05; // Increase opacity by 5% at each tick
            }
            else
            {
                fadeInTimer.Stop(); // Stop the fade-in timer when opacity reaches 100%
            }
        }

        // X button click event with fade-out effect
        private void X_Click(object sender, EventArgs e)
        {
            fadeOutTimer.Start();  // Start the fade-out animation
        }

        // PictureBox click event with fade-out effect
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            fadeOutTimer.Start();  // Start the fade-out animation
        }

        // Inject button click event
        private void button2_Click(object sender, EventArgs e)
        {
            // Call the injection method
            ForlornApi.Api.Inject();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ForlornApi.Api.ExecuteScript(Editor.Text);
        }

        private void status_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized; // Minimize the window
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Load the selected script into the editor
            Editor.Text = File.ReadAllText($"./workspace/Scripts/{listBox1.SelectedItem}");
        }

        // Method to open the Scripts folder when the button is clicked
        private void openScriptsButton_Click(object sender, EventArgs e)
        {
            // Path to the Scripts folder in the Workspace directory
            string scriptsFolderPath = Path.Combine(Application.StartupPath, "workspace", "Scripts");

            // Open the Scripts folder in File Explorer
            System.Diagnostics.Process.Start("explorer.exe", scriptsFolderPath);
        }

        private void Button_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            functions.PopulateListBox(listBox1, "./workspace/Scripts", "*.lua");
            functions.PopulateListBox(listBox1, "./workspace/Scripts", "*.txt");
        }

        private void Button_MouseDown(object sender, MouseEventArgs e)
        {
            mouseLocation = new Point(-e.X, -e.Y); // Store the mouse location for dragging
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point mousePose = Control.MousePosition; // Get current mouse position
                mousePose.Offset(mouseLocation.X, mouseLocation.Y);
                Location = mousePose; // Update window location for dragging
            }
        }

        private void Editor_Load(object sender, EventArgs e)
        {
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void robloxopen_Click(object sender, EventArgs e)
        {
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        // Helper class for populating ListBox
        class functions
        {
            public static void PopulateListBox(System.Windows.Forms.ListBox lsb, string Folder, string SearchPattern)
            {
                string[] files = Directory.GetFiles(Folder, SearchPattern);
                foreach (string file in files)
                {
                    string fileName = Path.GetFileName(file);
                    lsb.Items.Add(fileName);
                }
            }
        }
    }
}
